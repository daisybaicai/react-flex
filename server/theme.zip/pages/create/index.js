const createScreen = () => {
    return (
        <div>
            创建页面
        </div>
    );
}
 
export default createScreen;