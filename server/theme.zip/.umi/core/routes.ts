import { ApplyPluginsType } from '/Users/daisiyao/Desktop/boi/myapp/node_modules/@umijs/runtime';
import { plugin } from './plugin';

const routes = [
  {
    "path": "/create/blueChain",
    "exact": true,
    "component": require('@/pages/create/blueChain/index.js').default
  },
  {
    "path": "/create/darkChain",
    "exact": true,
    "component": require('@/pages/create/darkChain/index.js').default
  },
  {
    "path": "/create",
    "exact": true,
    "component": require('@/pages/create/index.js').default
  },
  {
    "path": "/",
    "exact": true,
    "component": require('@/pages/index.js').default
  }
];

// allow user to extend routes
plugin.applyPlugins({
  key: 'patchRoutes',
  type: ApplyPluginsType.event,
  args: { routes },
});

export { routes };
